	
	<link rel="stylesheet" href="./css/sidebar.css">

	<style>

*{
	padding: 0;
	margin: 0;
}

.sidebar{
	position: absolute;
	width: 240px;
	height: 100%;
	left: 0;
	background:transparent;
	border-right:solid;
	border-color: #792c1a;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;

}
.sidebar .text{
	color: #ffdb0d;
	font-size: 30px;
	font-weight: 600;
	line-height: 50px;
	text-align: center;
	text-decoration: none;
	background: #792c1a;
	letter-spacing: 1px;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;
}
nav ul{
	background: transparent;
	width: 100%;
	height: 100%;
	list-style: none;

}
nav ul li{
	line-height:40px;
	border-bottom: 1px solid rgba(0,0,0,0.5);
	
}

nav ul li a{
	position: relative;
	color: black;
	text-decoration: none;
	font-size: 17px;
	padding-left: 40px;
	font-weight: 400;
	display: block;
	width: 100%;
	font-weight: bold;
	border-left: 3px solid transparent;
	background-color:#FEDE00;
	font-size: 18px;
	height: 42px;
}
nav ul li a:hover{
	color: #ffdb0d;
	background: #792c1a;
	border-left: 3px solid #ffdb0d;
}

nav ul li a:focus{
	background: #792c1a;
	border-left: 3px solid #ffdb0d;
	
	
}

nav ul ul {
	position: static;
	display: none;
}
nav ul .stud-show.show{
	display: block;
}
nav ul .fac-show.show1{
	display: block;
}
nav ul .adm-show.show2{
	display: block;
}
nav ul ul li{
	line-height:27px;
	border-bottom: none;
}
nav ul ul li a{
	font-size: 14px;
	padding-left: 80px;
}
nav ul  li a span{
	position: absolute;
	top: 50%;
	right: 20px;
	transform: translateY(-50%);
	font-size: 22px;
	color: black;
	transition: transform 0.4s;
}
nav ul  li a span.rotate{
transform: translateY(-50%) rotate(-180deg);
}
nav ul  li a:hover span{
	color: #ffdb0d;
}
.as{
 
border-top: solid;
border-bottom: solid;
border-color: #ffdb0d;
background-size: auto;
padding:20px;
background-position: center;
background-size: cover;
margin: 0px;
margin-right: 0px;

}
.ab{
color: black;
text-shadow: 2px 2px 0 #000000, 2px -2px 0 #000000, -2px 2px 0 #000000 , -2px -2px 0 #000000, 2px 0px 0 #000000, 0px 2px 0 #000000, -2px 0px 0 #000000, 0px -2px 0 #000000;
color: #ffdb0d;
font-size: 75px;

}
.user{
	text-align: right;

}
.user-img {
        border-radius: 50%;
        height: 25px;
        width: 25px;
        object-fit: cover;
    }

	.sidebar .text{
		background: #792c1a;
	}



	.dash{
		width:30px;
		position:relative;
		left:8px;
		bottom:470px;
	
	}



	</style>



	 <div class="sidebar">
	<nav class="m.2">
		<div class="text">Admin</div>
		<ul>
		
			<li><a href="./" >Dashboard</a></li>
			<li>
				<a href="./index.php?page=subject_list">Subjects</a>
			</li>
			<li>
				<a href="./index.php?page=class_list">Classes</a>
			</li>
			<li>
				<a href="./index.php?page=academic_list">Academic Year</a>
			</li> 
			<li>
				<a href="./index.php?page=questionnaire">Questionnaires</a>
			</li>
			<li class="nav-item dropdown">
				<a href="./index.php?page=criteria_list" >Criteria</a>
			</li>
			<li>
				<a href="#" class="stud-btn">Students
					<span class="fas fa-caret-down first"></span>
				</a>
				<ul class="stud-show">
					<li><a href="./index.php?page=new_student">Add Student</a></li>
					<li><a href="./index.php?page=student_list">List</a></li>

				</ul>	
			</li>
			<li>
				<a href="#" class="fac-btn">Faculties
					<span class="fas fa-caret-down second"></span>
				</a>
				<ul class="fac-show">
					<li><a href="./index.php?page=new_faculty">Add Faculty</a></li>
					<li><a href="./index.php?page=faculty_list">List</a></li>

				</ul>	
			</li>
			
			<li>
				<a href="#" class="adm-btn">Admins
					<span class="fas fa-caret-down third"></span>
				</a>
				<ul class="adm-show">
					<li><a href="./index.php?page=new_user">Add</a></li>
					<li><a href="./index.php?page=user_list">List</a></li>
				</ul>	
			</li>
			<li>
				<a href="./index.php?page=report">Evaluation Reports</a>
			</li>

			<li>
				<a href="./index.php?page=archived">Archived</a>
			</li>
		</ul>

		<img class="dash" src="./images/dashboard.png">


	</nav>
</div>






	<script>


		$('.stud-btn').click(function(){
			$('nav ul .stud-show').toggleClass("show");
			$('nav ul .first').toggleClass("rotate");
		});
		$('.fac-btn').click(function(){
			$('nav ul .fac-show').toggleClass("show1");
			$('nav ul .second').toggleClass("rotate");
		});
		$('.adm-btn').click(function(){
			$('nav ul .adm-show').toggleClass("show2");
			$('nav ul .third').toggleClass("rotate");
		});



	</script>
