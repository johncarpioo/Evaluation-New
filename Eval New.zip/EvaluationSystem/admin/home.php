<?php include('db_connect.php'); ?>
<?php 
function ordinal_suffix1($num){
    $num = $num % 100; // protect against large numbers
    if($num < 11 || $num > 13){
         switch($num % 10){
            case 1: return $num.'st';
            case 2: return $num.'nd';
            case 3: return $num.'rd';
        }
    }
    return $num.'th';
}
$astat = array("Not Yet Started","On-going","Closed");
 ?>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="./css/home.css">
 <div class="home">
 <div class="heading">
        <div class="col-md-5">
          <div class="callout callout-info">
            <h1>Status of Evaluation: <?php echo $astat[$_SESSION['academic']['status']] ?></h1>  
            <h1>Academic Year: <?php echo $_SESSION['academic']['year'].' '.(ordinal_suffix1($_SESSION['academic']['semester'])) ?> Semester</h1>
            
          </div>
        </div>
     
</div>
        <div class="row">
          <p class="wcpo"> Welcome <?php echo ucwords($_SESSION['login_firstname']) ?>, Have a Nice Day!</p>
          <div class="column">
            
              <p>STUDENTS</p>
                <h3><?php echo $conn->query("SELECT * FROM student_list")->num_rows; ?></h3>
                
              
          </div>
           <div class="column">
            
                

               <p>FACULTIES</p>
                <h3><?php echo $conn->query("SELECT * FROM faculty_list ")->num_rows; ?></h3>
              
          </div>
           <div class="column">
           
                 <p>CLASSES</p>
                <h3><?php echo $conn->query("SELECT * FROM class_list")->num_rows; ?></h3>

             
          </div>
          <div class="column">
              
                

                
                <p>ADMINS</p>
                 <h3><?php echo $conn->query("SELECT * FROM users")->num_rows; ?></h3>
              
          </div>
      </div>
      <br>
      <br>
      <div id="footer" class="text-center">
        <div class="container">
          <div class="socials-media text-center">
    
            <ul class="list-unstyled">
              <li><a href="twitter.com"><i class="ion-social-twitter"></i></a></li>
              <li><a href="instagram.com"><i class="ion-social-instagram"></i></a></li>
            </ul>
    
          </div>
    
          
          <div class="credits">
            Pambayang Dalubhasaan ng Marilao
            <p>2021 All Rights Reserved.</p>
            <p>
              <br><a href="https://www.edukasyon.ph/schools/pambayang-dalubhasaan-ng-marilao">www.edukasyon.ph/schools/pambayang-dalubhasaan-ng-marilao</p></a>
          </div>
    </div>
    </div>
