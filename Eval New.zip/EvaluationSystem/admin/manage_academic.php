<?php
include '../db_connect.php';
if(isset($_GET['id'])){
	$qry = $conn->query("SELECT * FROM academic_list where id={$_GET['id']}")->fetch_array();
	foreach($qry as $k => $v){
		$$k = $v;
	}
}
?>
<link rel="stylesheet" href="./css/manage_subject.css">
<div class="subMan">
	<div class="smf">ADD/EDIT ACADEMIC YEAR</div>
<hr />
	<form action="" id="manage-academic">
		<div class="subform">
			<label for="year" class="control-label">Year</label>
			<br>
			<input type="text" class="form-control form-control-sm" name="year" id="year" value="<?php echo isset($year) ? $year : '' ?>" placeholder="(2019-2020)" required>
		</div>
		<div class="subform">
			<label for="semester" class="control-label">Semester</label>
			<br>
			<input type="number" class="form-control form-control-sm" name="semester" id="semester" value="<?php echo isset($semester) ? $semester : '' ?>" required>
		</div>
		<?php if(isset($status)): ?>
		<div class="subform">
			<label for="" class="control-label">Status</label>
			<br>
			<select name="status" id="status" class="form-control form-control-sm">
				<option value="0" <?php echo $status == 0 ? "selected" : "" ?>>Pending</option>
				<option value="1" <?php echo $status == 1 ? "selected" : "" ?>>Started</option>
				<option value="2" <?php echo $status == 2 ? "selected" : "" ?>>Closed</option>
			</select>
		</div>
		<?php endif; ?>
	</form>

</div>
<script>
	$(document).ready(function(){
		$('#manage-academic').submit(function(e){
			location.replace('index.php?page=academic_list')
			e.preventDefault();
			start_load()
			$('#msg').html('')
			$.ajax({
				url:'ajax.php?action=save_academic',
				method:'POST',
				data:$(this).serialize(),
				success:function(resp){
					if(resp == 1){
						alert_toast("Data successfully saved.","success");
						setTimeout(function(){
							location.reload()	
						},1750)
					}else if(resp == 2){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> academic Code already exist.</div>')
						end_load()
					}
				}
			})
		})
	})

</script>